@extends('layouts.main')
@section('title', 'Beranda')
@section('content')
    <div class="content-page">
        <div class="content">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        {{-- <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Layouts</a></li>
                                    <li class="breadcrumb-item active">Detached</li>
                                </ol>
                            </div> --}}
                        <h4 class="page-title">Beranda</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="tab-content">
                                <h3>Selamat datang di LaundrySense</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- End Content -->
    </div>
@endsection
