
<?php $__env->startSection('title', 'Transaksi'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('beranda.index')); ?>">Beranda</a></li>
                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo $__env->yieldContent('title'); ?></h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <form id="form">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="pelanggan" class="form-label">Pelanggan</label>
                                <select name="pelanggan" id="pelanggan" class="form-control">
                                    <option value="">-- Pilih Pelanggan --</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">Data Tidak Tersedia</option>
                                    <?php endif; ?>
                                </select>
                                <div class="invalid-feedback errorPelanggan"></div>
                            </div>
                            <div class="row">
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="jenis_pakaian" class="form-label">Jenis Pakaian</label>
                                            <select name="jenis_pakaian" id="jenis_pakaian" class="form-control">
                                                <option value="">-- Pilih Jenis --</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->jenis_pakaian); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="">Data Tidak Tersedia</option>
                                                <?php endif; ?>
                                            </select>
                                            <div class="invalid-feedback errorJenisPakaian"></div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="harga" class="form-label">Harga</label>
                                            <input type="text" name="harga" id="harga" class="form-control"
                                                readonly>
                                            <div class="invalid-feedback errorHarga"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="berat" class="form-label">Berat (Kg)</label>
                                            <input type="number" name="berat" id="berat" class="form-control"
                                                value="0">
                                            <div class="invalid-feedback errorBerat"></div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="jumlah" class="form-label">Total Harga</label>
                                            <input type="number" name="jumlah" id="jumlah" class="form-control" value="0"
                                                readonly>
                                            <div class="invalid-feedback errorJumlah"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="tgl_mulai" class="form-label">Tanggal Mulai</label>
                                        <input type="date" name="tgl_mulai" id="tgl_mulai" class="form-control">
                                        <div class="invalid-feedback errorTanggalMulai"></div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="tgl_selesai" class="form-label">Tanggal Selesai</label>
                                        <input type="date" name="tgl_selesai" id="tgl_selesai" class="form-control">
                                        <div class="invalid-feedback errorTanggalSelesai"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" class="btn btn-secondary mb-2"
                                    onclick="window.location='<?php echo e(route('transaksi.index')); ?>'">Kembali</button>
                                <button type="submit" class="btn btn-primary mb-2" id="simpan">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
    </div>

    <script>
        $(document).ready(function() {
            $('#jenis_pakaian').on('change', function() {
                // Mengambil ID jenis pakaian yang dipilih
                var jenisPakaianId = $(this).val();

                // Mengirim permintaan Ajax untuk mengambil harga
                $.ajax({
                    url: '/transaksi/get-harga', // Ubah sesuai dengan URL endpoint Anda
                    type: 'GET',
                    data: {
                        jenis_pakaian_id: jenisPakaianId
                    },
                    success: function(response) {
                        // Menampilkan harga di dalam input harga
                        $('#harga').val(response.harga);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            });

            $('#berat, #jenis_pakaian').on('input', function() {
                // Mengambil nilai berat dan harga
                var berat = parseFloat($('#berat').val());
                var harga = parseFloat($('#harga').val());

                // Mengalikan berat dengan harga
                var total = berat * harga;

                // Memasukkan nilai total ke dalam input jumlah
                $('#jumlah').val(total.toFixed(3));
            });
        });

        $('#form').submit(function(e) {
            e.preventDefault();
            $.ajax({
                data: $(this).serialize(),
                url: "<?php echo e(route('transaksi.store')); ?>",
                type: "POST",
                dataType: 'json',
                beforeSend: function() {
                    $('#simpan').attr('disabled', 'disabled');
                    $('#simpan').text('Proses...');
                },
                complete: function() {
                    $('#simpan').removeAttr('disabled');
                    $('#simpan').html('Simpan');
                },
                success: function(response) {
                    if (response.errors) {
                        if (response.errors.pelanggan) {
                            $('#pelanggan').addClass('is-invalid');
                            $('.errorPelanggan').html(response.errors.pelanggan);
                        } else {
                            $('#pelanggan').removeClass('is-invalid');
                            $('.errorPelanggan').html('');
                        }

                        if (response.errors.berat) {
                            $('#berat').addClass('is-invalid');
                            $('.errorBerat').html(response.errors.berat);
                        } else {
                            $('#berat').removeClass('is-invalid');
                            $('.errorBerat').html('');
                        }

                        if (response.errors.jenis_pakaian) {
                            $('#jenis_pakaian').addClass('is-invalid');
                            $('.errorJenisPakaian').html(response.errors.jenis_pakaian);
                        } else {
                            $('#jenis_pakaian').removeClass('is-invalid');
                            $('.errorJenisPakaian').html('');
                        }

                        if (response.errors.jumlah) {
                            $('#jumlah').addClass('is-invalid');
                            $('.errorJumlah').html(response.errors.jumlah);
                        } else {
                            $('#jumlah').removeClass('is-invalid');
                            $('.errorJumlah').html('');
                        }

                        if (response.errors.tgl_mulai) {
                            $('#tgl_mulai').addClass('is-invalid');
                            $('.errorTanggalMulai').html(response.errors.tgl_mulai);
                        } else {
                            $('#tgl_mulai').removeClass('is-invalid');
                            $('.errorTanggalMulai').html('');
                        }

                        if (response.errors.tgl_selesai) {
                            $('#tgl_selesai').addClass('is-invalid');
                            $('.errorTanggalSelesai').html(response.errors.tgl_selesai);
                        } else {
                            $('#tgl_selesai').removeClass('is-invalid');
                            $('.errorTanggalSelesai').html('');
                        }
                    } else {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sukses',
                            text: response.success,
                        }).then(function() {
                            top.location.href =
                                "<?php echo e(route('transaksi.index')); ?>";
                        });
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    console.error(xhr.status + "\n" + xhr.responseText + "\n" +
                        thrownError);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaundrySense\resources\views/transaksi/create.blade.php ENDPATH**/ ?>