
<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-page">
        <div class="content">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        
                        <h4 class="page-title">Beranda</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="tab-content">
                                <h3>Selamat datang di LaundrySense</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- End Content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaundrySense\resources\views/beranda.blade.php ENDPATH**/ ?>